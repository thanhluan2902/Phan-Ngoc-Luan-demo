<?php
require_once 'controllers/Controller.php';
class ClientController extends Controller {

}
?>
