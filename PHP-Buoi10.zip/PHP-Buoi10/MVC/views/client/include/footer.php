    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="<?php echo URL ?>js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="<?php echo URL ?>js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="<?php echo URL ?>js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="<?php echo URL ?>js/plugins.js"></script>
    <!-- Active js -->
    <script src="<?php echo URL ?>js/active.js"></script>