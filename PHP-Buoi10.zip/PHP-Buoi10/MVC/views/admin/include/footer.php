<script src="<?php echo URL ?>vendor/jquery/jquery.min.js"></script>
<script src="<?php echo URL ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo URL ?>vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo URL ?>js/sb-admin-2.min.js"></script>